package testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class ServiceWrapperTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
