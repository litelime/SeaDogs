package domain;

public class IdException extends Exception{
    /**
	 * 
	 */
	private static final long serialVersionUID = 2689695810932204301L;

	public IdException(String msg){
        super(msg);
     }

}
